package r0.r0b0t.client;

import net.fabricmc.api.ClientModInitializer;

public class R0BOTClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		// This entrypoint is suitable for setting up client-specific logic, such as rendering.
	}
}